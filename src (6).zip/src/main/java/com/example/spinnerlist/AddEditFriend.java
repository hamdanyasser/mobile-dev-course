package com.example.spinnerlist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddEditFriend extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_edit_friend);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnSubmit =  findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText etName = findViewById(R.id.etName);
                EditText etLastName = findViewById(R.id.etLastName);
                EditText etPhone = findViewById(R.id.etPhone);


                Friend  friend = new Friend();
                friend.setFirstName(etName.getText().toString());
                friend.setLastName(etLastName.getText().toString());
                friend.setPhone(etPhone.getText().toString());

                Intent ReplyIntent = new Intent();
                ReplyIntent.putExtra("NewFriend",friend);

                setResult(RESULT_OK, ReplyIntent);
                finish();


            }
        });
    }


}