package com.example.spinnerlist;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Friend implements Parcelable {

    private  String FirstName;
    private  String LastName;
    private  String Phone;

    private  String Gender;
    private  String Relationship;

    public  Friend()
    {

    }

    protected Friend(Parcel in) {
        FirstName = in.readString();
        LastName = in.readString();
        Phone = in.readString();
        Gender = in.readString();
        Relationship = in.readString();
    }

    public static final Creator<Friend> CREATOR = new Creator<Friend>() {
        @Override
        public Friend createFromParcel(Parcel in) {
            return new Friend(in);
        }

        @Override
        public Friend[] newArray(int size) {
            return new Friend[size];
        }
    };

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getRelationship() {
        return Relationship;
    }

    public String getFullName() {
        return getFirstName() + " " + getLastName();
    }

    public void setRelationship(String relationship) {
        Relationship = relationship;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(FirstName);
        dest.writeString(LastName);
        dest.writeString(Phone);
        dest.writeString(Gender);
        dest.writeString(Relationship);
    }
}
