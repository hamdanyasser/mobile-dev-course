package com.example.spinnerlist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddEditFriend extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_edit_friend);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        Spinner spinner = (Spinner) findViewById(R.id.spnRelationShip);
spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
});

        ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(
                        getApplicationContext(), R.array.relationship_type,
                        // Layout for each item
                        android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        assert spinner != null;
        spinner.setAdapter(adapter);


        Button btnSubmit =  findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText etName = findViewById(R.id.etName);
                EditText etLastName = findViewById(R.id.etLastName);
                EditText etPhone = findViewById(R.id.etPhone);
                Spinner spinner = (Spinner) findViewById(R.id.spnRelationShip);

                Friend  friend = new Friend();
                friend.setFirstName(etName.getText().toString());
                friend.setLastName(etLastName.getText().toString());
                friend.setPhone(etPhone.getText().toString());
                friend.setRelationship(spinner.getSelectedItem().toString());


                Intent ReplyIntent = new Intent();
                ReplyIntent.putExtra("NewFriend",friend);

                setResult(RESULT_OK, ReplyIntent);
                finish();


            }
        });
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}