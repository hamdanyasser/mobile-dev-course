package com.example.onactivityresultlab;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddCustomer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_customer);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnCancel = findViewById(R.id.btnCancel);
        Button btnSave= findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText etName = findViewById(R.id.etName);
                EditText etPhone = findViewById(R.id.etPhone);

                // Create an intent
                Intent replyIntent = new Intent();

                Friend newfriend = new Friend();
                newfriend.setName(etName.getText().toString());
                newfriend.setPhone(etPhone.getText().toString());


                // Put the data to return into the extra
                replyIntent.putExtra("NewFriend",  newfriend);
                // Set the activity's result to RESULT_OK
                setResult(RESULT_OK, replyIntent);
                // Finish the current activity
                finish();

            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent replyIntent = new Intent();
                // Put the data to return into the extra

                setResult(RESULT_CANCELED, replyIntent);
                // Finish the current activity
                finish();
            }
        });
    }
}