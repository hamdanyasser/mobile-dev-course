package com.example.onactivityresultlab;

import static android.widget.LinearLayout.HORIZONTAL;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnAddCustomer = findViewById(R.id.btnAddCustomer);
        btnAddCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddCustomer.class);
                startActivityForResult(intent, 1);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ( requestCode==1 && resultCode ==RESULT_OK)
        {
        Friend newFriend = data.getParcelableExtra("NewFriend");

            LinearLayout friendLayout = new LinearLayout(this);
            friendLayout.setOrientation(HORIZONTAL);

            ImageView img = new ImageView(this);

            friendLayout.addView(img);

            TextView viewFriend = new TextView(this);
            viewFriend.setText(newFriend.getName() + " - " + newFriend.getPhone());
            friendLayout.addView(viewFriend);

            LinearLayout main = findViewById(R.id.mainLayout);

            main.addView(friendLayout);


        // Toast.makeText(this,"You Saved " + name, Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(this,"Process Canceled ", Toast.LENGTH_LONG).show();
        }

    }
}